const backgroundMusic = new Audio("game-music.mp3");
backgroundMusic.loop = true; // Loop the music
backgroundMusic.volume = 0.6; // Default volume level (60%)
const volumeSlider = document.getElementById("volume-slider");
const volumeLabel = document.getElementById("volume-label");
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const startBtn = document.getElementById("start-btn");
const restartBtn = document.getElementById("restart-btn");
const scoreBoard = document.getElementById("score-board");
const scoreDisplay = document.getElementById("score");
// Create a new image element for the apple clipart
const appleImage = new Image();
appleImage.src = 'apple.png'; // Path to your apple image

canvas.width = 400;
canvas.height = 600;

// Game variables
let player = { x: canvas.width / 2 - 20, y: canvas.height - 50, width: 120, height: 20 };
let objects = [];
let score = 0;
let gameOver = false;
let gameInterval;
let objectInterval;

// Add objects to fall
function createObject() {
  const size = 20;
  const x = Math.random() * (canvas.width - size);
  const speed = 1 + Math.random() * 1;
  objects.push({ x, y: 0, width: size, height: size, speed });
}


// Draw the player (black hole) as an oval
function drawPlayer() {
  ctx.fillStyle = "black"; // Black color for the black hole

  // Draw the black hole as an oval shape
  ctx.beginPath();
  ctx.ellipse(player.x + player.width / 2, player.y + player.height / 2, player.width / 2, player.height / 2, 0, 0, Math.PI * 2);
  ctx.closePath();
  ctx.fill();
}


// Function to update the movement of apples towards the black hole (if close enough)
function updateApplePosition() {
  objects.forEach((apple, index) => {
    // Calculate the distance from the apple to the center of the black hole
    const dx = apple.x + apple.width / 2 - (player.x + player.width / 2);
    const dy = apple.y + apple.height / 2 - (player.y + player.height / 2);
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    // If the apple is close enough to the black hole, move it towards the center
    if (distance < 150) {  // You can adjust this threshold
      // The closer the apple, the faster it moves
      const pullStrength = Math.min(1 + (150 - distance) / 100, 3); // Gradually increase speed as it gets closer
      apple.x -= dx / (20 * pullStrength);  // Adjust how fast the apple is pulled in
      apple.y -= dy / (20 * pullStrength);  // Adjust how fast the apple is pulled in
    }
  });
}








// Draw objects as apples (using the apple image)
function drawObjects() {
  objects.forEach(obj => {
    ctx.drawImage(appleImage, obj.x, obj.y, obj.width * 2, obj.height * 2); // Resize to half its original size
  });
}


// Move objects
function moveObjects() {
  objects.forEach(obj => {
    obj.y += obj.speed;
  });
}

// Check collision
function checkCollision() {
  objects.forEach((obj, index) => {
    if (
      obj.x < player.x + player.width &&
      obj.x + obj.width > player.x &&
      obj.y < player.y + player.height &&
      obj.y + obj.height > player.y
    ) {
      objects.splice(index, 1);
      score++;
      scoreDisplay.textContent = score;
    } else if (obj.y > canvas.height) {
      gameOver = true;
    }
  });
}

// Update game
function update() {
  if (gameOver) {
    endGame();
    return;
  }

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  drawPlayer();
  drawObjects();
  moveObjects();
  checkCollision();
}

// Start game
function startGame() {
  score = 0;
  gameOver = false;
  objects = [];
  player.x = canvas.width / 2 - 20;
  
  // Show canvas and score
  canvas.style.display = "block";
  scoreBoard.style.display = "block";

  // Hide start button
  startBtn.style.display = "none";
  restartBtn.style.display = "none";
  
  // Play background music
  backgroundMusic.play();

  // Start game loop
  objectInterval = setInterval(createObject, 2000);
  gameInterval = setInterval(() => {
    update();
    requestAnimationFrame(update);
  }, 20);
}

// End game
function endGame() {
  backgroundMusic.pause(); // Pause music when the game ends

  clearInterval(gameInterval);
  clearInterval(objectInterval);

  restartBtn.style.display = "block";
  alert("Game Over! Your Score: " + score);
}

// Restart game
function restartGame() {
  startGame();
}

// Controls
document.addEventListener("keydown", e => {
  if (e.key === "ArrowLeft" && player.x > 0) {
    player.x -= 40;
  } else if (e.key === "ArrowRight" && player.x + player.width < canvas.width) {
    player.x += 40;
  }
});

// Button event listeners
startBtn.addEventListener("click", startGame);
restartBtn.addEventListener("click", restartGame);

// Volume control
volumeSlider.addEventListener("input", () => {
  const volumeLevel = volumeSlider.value;
  backgroundMusic.volume = volumeLevel / 4; // Convert slider value to volume level (0 to 1 scale)
  
  // Update volume label text
  const levels = ["Muted", "Level 1", "Level 2", "Level 3", "Level 4"];
  volumeLabel.textContent = levels[volumeLevel];
});
